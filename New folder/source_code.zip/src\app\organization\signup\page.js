﻿'use client';
import { useState, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Mail, Lock, AlertCircle, CheckCircle, Building2, User, Phone, MapPin, Globe, Calendar, Upload, X, CreditCard, ExternalLink, Copy, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function OrganizationSignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    country: 'US', // Default to US
    postalCode: '',
    website: '',
    logo: '', // Base64 encoded logo
    logoUrl: '', // URL returned from PHP API
    // Stripe Connect Account Information (Step 3)
    createStripeAccount: true, // Default to true for Step 3
    // Organization Login Details (single password set) - Step 4
    orgPassword: '',
    confirmOrgPassword: '',
    // GHL Business Details (automatic - no checkbox needed)
    businessName: '',
    businessPhone: '',
    businessAddress: '',
    businessCity: '',
    businessState: '',
    businessCountry: 'US',
    businessPostalCode: '',
    businessWebsite: '',
    businessTimezone: 'America/New_York'
  });
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showOrgPassword, setShowOrgPassword] = useState(false);
  const [showConfirmOrgPassword, setShowConfirmOrgPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [logoPreview, setLogoPreview] = useState(null);
  const [logoUploading, setLogoUploading] = useState(false);
  const [signupSuccess, setSignupSuccess] = useState(false);
  const [onboardingLink, setOnboardingLink] = useState(null);
  const [organizationData, setOrganizationData] = useState(null);
  const [linkCopied, setLinkCopied] = useState(false);
  const totalSteps = 4; // Steps: Basic Info, Address, Stripe Connect, Organization Login

  // Clear errors when component mounts and fetch countries
  useEffect(() => {
    setErrors({});
    setErrorMsg('');
    fetchCountries();
  }, []);

  const fetchCountries = async () => {
    try {
      const response = await fetch('/api/countries?format=grouped');
      const data = await response.json();
      
      if (data.success) {
        // Combine popular countries first, then others
        const allCountries = [
          ...data.countries.popular,
          { code: 'separator', name: 'â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€' }, // Visual separator
          ...data.countries.others
        ];
        setCountries(allCountries);
      }
    } catch (error) {
      console.error('Error fetching countries:', error);
      // Fallback to basic countries if API fails
      setCountries([
        { code: "US", name: "United States", flag: "ðŸ‡ºðŸ‡¸" },
        { code: "GB", name: "United Kingdom", flag: "ðŸ‡¬ðŸ‡§" },
        { code: "CA", name: "Canada", flag: "ðŸ‡¨ðŸ‡¦" },
        { code: "AU", name: "Australia", flag: "ðŸ‡¦ðŸ‡º" },
        { code: "DE", name: "Germany", flag: "ðŸ‡©ðŸ‡ª" },
        { code: "FR", name: "France", flag: "ðŸ‡«ðŸ‡·" }
      ]);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    
    // Clear specific field error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
    
    // Clear general error message when user starts typing
    if (errorMsg) {
      setErrorMsg('');
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    if (step === 1) {
      // Basic Information
      if (!form.name.trim()) {
        newErrors.name = 'Organization name is required';
      }
      if (!form.email.trim()) {
        newErrors.email = 'Email is required';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
        newErrors.email = 'Please enter a valid email address';
      }
      if (!form.phone.trim()) {
        newErrors.phone = 'Phone number is required';
      }
      // Company name is now optional - no validation needed
    } else if (step === 2) {
      // Address Information
      if (!form.address.trim()) {
        newErrors.address = 'Address is required';
      }
      if (!form.city.trim()) {
        newErrors.city = 'City is required';
      }
      if (!form.state.trim()) {
        newErrors.state = 'State is required';
      }
      if (!form.postalCode.trim()) {
        newErrors.postalCode = 'Postal code is required';
      }
    } else if (step === 3) {
      // Stripe Connect Account Information - only country is required
      if (form.createStripeAccount) {
        if (!form.country) {
          newErrors.country = 'Country is required for Stripe account';
        }
      }
    } else if (step === 4) {
      // Organization Login Details
      if (!form.orgPassword) {
        newErrors.orgPassword = 'Organization password is required';
      } else if (form.orgPassword.length < 6) {
        newErrors.orgPassword = 'Organization password must be at least 6 characters long';
      }
      if (!form.confirmOrgPassword) {
        newErrors.confirmOrgPassword = 'Please confirm your organization password';
      } else if (form.orgPassword !== form.confirmOrgPassword) {
        newErrors.confirmOrgPassword = 'Organization passwords do not match';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, totalSteps));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  // Logo upload functions
  const convertToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  };

  const uploadLogoToAPI = async (base64Data) => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_IMAGE_UPLOAD_URL || process.env.IMAGE_UPLOAD_URL;
      
      console.log('Logo upload attempt:', {
        hasApiUrl: !!apiUrl,
        apiUrl: apiUrl,
        hasBase64Data: !!base64Data,
        base64Length: base64Data?.length
      });
      
      if (!apiUrl) {
        console.warn('Image upload API URL not configured, skipping upload');
        return null; // Return null instead of throwing error
      }

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: base64Data
        }),
      });

      if (!response.ok) {
        console.error('Upload API response not ok:', response.status, response.statusText);
        return null; // Return null instead of throwing error
      }

      const data = await response.json();
      return data.image_url;
    } catch (error) {
      console.error('Logo upload error:', error);
      return null; // Return null instead of throwing error
    }
  };

  const handleLogoChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Image size must be less than 5MB');
      return;
    }

    setErrorMsg('');

    try {
      // Create preview
      const previewUrl = URL.createObjectURL(file);
      setLogoPreview(previewUrl);

      // Convert to base64 and store for later upload
      const base64Data = await convertToBase64(file);
      
      // Update form with base64 data (will upload on submit)
      setForm(prev => ({
        ...prev,
        logo: base64Data,
        logoUrl: '' // Will be set during upload on submit
      }));

    } catch (error) {
      console.error('Logo processing error:', error);
      setErrorMsg('Failed to process logo. Please try again.');
      setLogoPreview(null);
    }
  };

  const removeLogo = () => {
    if (logoPreview) {
      URL.revokeObjectURL(logoPreview);
    }
    setLogoPreview(null);
    setForm(prev => ({
      ...prev,
      logo: '',
      logoUrl: ''
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateStep(currentStep)) {
      return;
    }

    if (currentStep < totalSteps) {
      handleNext();
      return;
    }

    setIsSubmitting(true);
    setLoading(true);
    setErrorMsg('');

    try {
      // Upload logo if present
      let logoUrl = form.logoUrl;
      console.log('Submit - Logo check:', {
        hasLogo: !!form.logo,
        hasLogoUrl: !!form.logoUrl,
        logoLength: form.logo?.length
      });
      
      if (form.logo && !form.logoUrl) {
        console.log('Starting logo upload...');
        setLogoUploading(true);
        try {
          logoUrl = await uploadLogoToAPI(form.logo);
          if (logoUrl) {
            console.log('Logo uploaded successfully:', logoUrl);
          } else {
            console.warn('Logo upload failed, proceeding without logo URL');
          }
        } catch (uploadError) {
          console.error('Logo upload error:', uploadError);
          // Continue with registration even if logo upload fails
        } finally {
          setLogoUploading(false);
        }
      }

      // Prepare form data with logo URL
      const formData = {
        ...form,
        logoUrl: logoUrl || form.logoUrl
      };

      const res = await fetch('/api/organization', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        const apiError = data?.error;
        const normalized = typeof apiError === 'string'
          ? apiError
          : (apiError?.message || apiError?.code || apiError?.validation || JSON.stringify(apiError) || 'Registration failed. Please try again.');
        setErrorMsg(normalized);
        return;
      }

      // Store signup success data
      setOrganizationData(data.organization);
      setOnboardingLink(data.stripeOnboardingLink);
      setSignupSuccess(true);
    } catch (err) {
      console.error('Registration error:', err);
      const normalized = typeof err?.message === 'string' ? err.message : 'Network error. Please check your connection and try again.';
      setErrorMsg(normalized);
    } finally {
      setLoading(false);
      setIsSubmitting(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
            <motion.div variants={itemVariants} className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Basic Information</h2>
              <p className="text-gray-600">Let&apos;s start with your organization details</p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Organization Name *
              </label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="name"
                  type="text"
                  placeholder="Enter organization name"
                  value={form.name}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.name 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
              </div>
              <AnimatePresence>
                {errors.name && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.name}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>


            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="email"
                  type="email"
                  placeholder="Enter your email"
                  value={form.email}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.email 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
              </div>
              <AnimatePresence>
                {errors.email && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.email}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Phone Number *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="phone"
                  type="tel"
                  placeholder="Enter phone number"
                  value={form.phone}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.phone 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
              </div>
              <AnimatePresence>
                {errors.phone && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.phone}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>


            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Website (Optional)
              </label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="website"
                  type="url"
                  placeholder="https://your-website.com"
                  value={form.website}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 text-gray-900"
                  disabled={isSubmitting}
                />
              </div>
            </motion.div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
            <motion.div variants={itemVariants} className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Address Information</h2>
              <p className="text-gray-600">Where is your organization located?</p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Street Address *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="address"
                  type="text"
                  placeholder="Enter street address"
                  value={form.address}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.address 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
              </div>
              <AnimatePresence>
                {errors.address && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.address}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  City *
                </label>
                <input
                  name="city"
                  type="text"
                  placeholder="Enter city"
                  value={form.city}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.city 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
                <AnimatePresence>
                  {errors.city && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.city}</span>
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              <motion.div variants={itemVariants}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  State *
                </label>
                <input
                  name="state"
                  type="text"
                  placeholder="Enter state"
                  value={form.state}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.state 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
                <AnimatePresence>
                  {errors.state && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.state}</span>
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Country
                </label>
                <select
                  name="country"
                  value={form.country}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 text-gray-900"
                  disabled={isSubmitting}
                >
                  {countries.map((country) => (
                    country.code === 'separator' ? (
                      <option key="separator" disabled className="text-gray-400">
                        {country.name}
                      </option>
                    ) : (
                      <option key={country.code} value={country.code}>
                        {country.flag} {country.name}
                      </option>
                    )
                  ))}
                </select>
              </motion.div>

              <motion.div variants={itemVariants}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Postal Code *
                </label>
                <input
                  name="postalCode"
                  type="text"
                  placeholder="Enter postal code"
                  value={form.postalCode}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.postalCode 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
                <AnimatePresence>
                  {errors.postalCode && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.postalCode}</span>
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
            <motion.div variants={itemVariants} className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Stripe Connect Account</h2>
              <p className="text-gray-600">Set up your Stripe Connect account to receive payments</p>
            </motion.div>

            {/* Enable Stripe Connect Account */}
            <motion.div variants={itemVariants} className="p-4 bg-blue-50 border-2 border-blue-200 rounded-xl">
              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="createStripeAccount"
                  checked={form.createStripeAccount}
                  onChange={(e) => setForm(prev => ({ ...prev, createStripeAccount: e.target.checked }))}
                  className="mt-1 w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
                  disabled={isSubmitting}
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <CreditCard className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-semibold text-gray-900">
                      Create Stripe Connect Account
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 ml-7">
                    Create a Stripe Connect account to receive payments directly. You&apos;ll receive an email with a link to complete onboarding after registration.
                  </p>
                </div>
              </label>
            </motion.div>

            {form.createStripeAccount && (
              <motion.div variants={itemVariants}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Country for Stripe Account *
                </label>
                <select
                  name="country"
                  value={form.country}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.country 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                >
                  {countries.map((country) => (
                    country.code === 'separator' ? (
                      <option key="separator" disabled className="text-gray-400">
                        {country.name}
                      </option>
                    ) : (
                      <option key={country.code} value={country.code}>
                        {country.flag} {country.name}
                      </option>
                    )
                  ))}
                </select>
                <AnimatePresence>
                  {errors.country && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.country}</span>
                    </motion.p>
                  )}
                </AnimatePresence>
                <p className="text-xs text-gray-500 mt-2">
                  Select the country where your organization is located. This is required to create your Stripe account.
                </p>
              </motion.div>
            )}
          </motion.div>
        );

      case 4:
        return (
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
            <motion.div variants={itemVariants} className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Organization Login</h2>
              <p className="text-gray-600">Set up secure login credentials for your organization</p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Organization Password *
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="orgPassword"
                  type={showOrgPassword ? 'text' : 'password'}
                  placeholder="Create organization password"
                  value={form.orgPassword}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-12 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.orgPassword 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  onClick={() => setShowOrgPassword(!showOrgPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
                  disabled={isSubmitting}
                >
                  {showOrgPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <AnimatePresence>
                {errors.orgPassword && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.orgPassword}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Confirm Organization Password *
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  name="confirmOrgPassword"
                  type={showConfirmOrgPassword ? 'text' : 'password'}
                  placeholder="Confirm organization password"
                  value={form.confirmOrgPassword}
                  onChange={handleChange}
                  className={`w-full pl-10 pr-12 py-3 border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 text-gray-900 ${
                    errors.confirmOrgPassword 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-200 hover:border-gray-300 focus:border-blue-500'
                  }`}
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmOrgPassword(!showConfirmOrgPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
                  disabled={isSubmitting}
                >
                  {showConfirmOrgPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <AnimatePresence>
                {errors.confirmOrgPassword && (
                  <motion.p 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-red-500 text-sm mt-1 flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.confirmOrgPassword}</span>
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>

            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Organization Logo (Optional)
              </label>
              <div className="space-y-4">
                {logoPreview ? (
                  <div className="relative inline-block">
                    <div className="w-32 h-32 border-2 border-gray-200 rounded-xl overflow-hidden bg-gray-50">
                      <Image
                        src={logoPreview}
                        alt="Logo preview"
                        width={128}
                        height={128}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={removeLogo}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                      disabled={logoUploading}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-gray-400 transition-colors relative">
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 mb-2">Upload your organization logo</p>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF up to 5MB</p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      disabled={logoUploading || isSubmitting}
                    />
                  </div>
                )}
                {logoUploading && (
                  <div className="flex items-center justify-center space-x-2 text-blue-600">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                    <span className="text-sm">Uploading logo...</span>
                  </div>
                )}
              </div>
            </motion.div>

          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex flex-col lg:flex-row overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      {/* Left Side - Brand Section */}
      <motion.div
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative w-full lg:w-1/2 flex flex-col justify-center items-center p-8 lg:p-12 text-center z-10"
      >
        <div className="max-w-md">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="mb-8"
          >
            <Image
              src="/imgs/changeworks.jpg"
              alt="ChangeWorks Logo"
              width={200}
              height={200}
              className="mx-auto rounded-2xl shadow-2xl border-4 border-white/20 backdrop-blur-sm"
              priority
            />
          </motion.div>
          
          <motion.h1 
            variants={itemVariants}
            className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent mb-4"
          >
            Join ChangeWorks
          </motion.h1>
          
          <motion.p 
            variants={itemVariants}
            className="text-lg text-gray-600 mb-8 leading-relaxed"
          >
            Create your organization account and start making a difference in the world
          </motion.p>
          
          <motion.div 
            variants={itemVariants}
            className="flex items-center justify-center space-x-4 text-sm text-gray-500"
          >
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Free Registration</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>24/7 Support</span>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Right Side - Signup Form */}
      <motion.div
        initial={{ x: 100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative w-full lg:w-1/2 flex justify-center items-center p-8 lg:p-12 z-10"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="w-full max-w-md"
        >
          <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-8 lg:p-10">
            {/* Progress Bar */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Step {currentStep} of {totalSteps}</span>
                <span className="text-sm font-medium text-gray-600">{Math.round((currentStep / totalSteps) * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-[#0E0061] h-2 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${(currentStep / totalSteps) * 100}%` }}
                ></div>
              </div>
            </div>

            <AnimatePresence>
              {errorMsg && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center space-x-3"
                >
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                  <p className="text-red-700 text-sm">{errorMsg}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {signupSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                    className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <CheckCircle className="w-12 h-12 text-green-600" />
                  </motion.div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">Account Created Successfully!</h2>
                  <p className="text-gray-600">Your organization account has been created</p>
                </div>

                {onboardingLink && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="p-6 bg-blue-50 border-2 border-blue-200 rounded-xl"
                  >
                    <div className="flex items-center space-x-2 mb-4">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                      <h3 className="text-lg font-semibold text-gray-900">Stripe Onboarding Required</h3>
                    </div>
                    <p className="text-sm text-gray-700 mb-4">
                      To start receiving payments, you need to complete your Stripe account setup. Click the link below or copy it to complete the onboarding process.
                    </p>
                    
                    <div className="bg-white p-4 rounded-lg border-2 border-blue-300 mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-xs font-semibold text-gray-600">Onboarding Link:</span>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(onboardingLink);
                            setLinkCopied(true);
                            setTimeout(() => setLinkCopied(false), 2000);
                          }}
                          className="ml-auto flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
                        >
                          {linkCopied ? (
                            <>
                              <Check className="w-4 h-4" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <a
                        href={onboardingLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-700 text-sm break-all underline flex items-center space-x-1"
                      >
                        <span>{onboardingLink}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    <div className="flex space-x-3">
                      <a
                        href={onboardingLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-200 text-center flex items-center justify-center space-x-2"
                      >
                        <span>Complete Stripe Setup</span>
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>

                    <p className="text-xs text-gray-500 mt-4">
                      âš ï¸ This link will expire in 1 hour. If you need a new link, please contact support or use the resend link feature in your dashboard.
                    </p>
                  </motion.div>
                )}

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="p-4 bg-green-50 border-2 border-green-200 rounded-xl"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <h3 className="text-sm font-semibold text-gray-900">What&apos;s Next?</h3>
                  </div>
                  <ul className="text-sm text-gray-700 space-y-1 ml-7">
                    {onboardingLink && (
                      <li>â€¢ Complete your Stripe account onboarding using the link above</li>
                    )}
                    <li>â€¢ Check your email ({organizationData?.email}) for confirmation and additional information</li>
                    <li>â€¢ Sign in to your organization dashboard to get started</li>
                  </ul>
                </motion.div>

                <div className="flex space-x-4 mt-8">
                  <button
                    onClick={() => router.push('/organization/login')}
                    className="flex-1 bg-[#0E0061] text-white py-3 px-4 rounded-xl font-semibold hover:bg-[#0C0055] transition-all duration-200"
                  >
                    Go to Login
                  </button>
                </div>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit}>
                {renderStepContent()}

              <div className="flex space-x-4 mt-8">
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={handlePrevious}
                    className="flex-1 py-3 px-4 border-2 border-gray-200 text-gray-700 rounded-xl font-semibold hover:border-gray-300 transition-all duration-200"
                    disabled={isSubmitting}
                  >
                    Previous
                  </button>
                )}
                
                  <button
                  type="submit"
                  disabled={isSubmitting || logoUploading}
                  className="flex-1 bg-[#0E0061] text-white py-3 px-4 rounded-xl font-semibold hover:bg-[#0C0055] focus:outline-none focus:ring-2 focus:ring-[#0E0061]/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                >
                  {loading || logoUploading ? (
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>{logoUploading ? 'Uploading Logo...' : 'Creating Account...'}</span>
                    </div>
                  ) : currentStep === totalSteps ? (
                    'Create Account'
                  ) : (
                    'Next Step'
                  )}
                </button>
              </div>
            </form>
            )}

            <motion.div 
              variants={itemVariants}
              className="mt-8 text-center"
            >
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <a 
                  href="/organization/login" 
                  className="text-blue-600 hover:text-blue-700 font-semibold hover:underline transition-colors duration-200"
                >
                  Sign in here
                </a>
              </p>
            </motion.div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
