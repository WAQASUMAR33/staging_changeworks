'use client';

import { useState, useCallback, useEffect } from 'react';
import { usePlaidLink } from 'react-plaid-link';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, X, Loader2, CheckCircle, AlertCircle, Building2, Search, Heart, ArrowLeft, ArrowRight } from 'lucide-react';
import { buildOrgLogoUrl } from '@/lib/image-utils';
import Image from 'next/image';

const PlaidIntegration = ({ isOpen, onClose, onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1); // 1: Disclaimer, 2: Select Organization, 3: Connect Bank
  
  // Organization selection state
  const [organizations, setOrganizations] = useState([]);
  const [selectedOrganization, setSelectedOrganization] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loadingOrgs, setLoadingOrgs] = useState(false);

  // Persist selected organization in localStorage
  useEffect(() => {
    if (selectedOrganization) {
      localStorage.setItem('plaid-selected-org', JSON.stringify(selectedOrganization));
      console.log('Saved organization to localStorage:', selectedOrganization);
    }
  }, [selectedOrganization]);

  // Restore selected organization from localStorage on component mount
  useEffect(() => {
    const savedOrg = localStorage.getItem('plaid-selected-org');
    if (savedOrg) {
      try {
        const org = JSON.parse(savedOrg);
        setSelectedOrganization(org);
        console.log('Restored organization from localStorage:', org);
      } catch (error) {
        console.error('Error parsing saved organization:', error);
        localStorage.removeItem('plaid-selected-org');
      }
    }
  }, []);

  // Fetch organizations when component mounts
  useEffect(() => {
    if (isOpen) {
      fetchOrganizations();
    } else {
      // Clear localStorage when modal is closed
      localStorage.removeItem('plaid-selected-org');
    }
  }, [isOpen]);

  const fetchOrganizations = async () => {
    try {
      setLoadingOrgs(true);
      const response = await fetch('/api/organizations/list');
      const data = await response.json();
      
      if (data.success && data.organizations && Array.isArray(data.organizations)) {
        setOrganizations(data.organizations);
        console.log(`✅ Loaded ${data.count} organizations for Plaid`);
      } else {
        console.error('❌ Failed to fetch organizations:', data.error);
        setOrganizations([]);
      }
    } catch (error) {
      console.error('❌ Error fetching organizations:', error);
      setOrganizations([]);
    } finally {
      setLoadingOrgs(false);
    }
  };

  const onPlaidSuccess = useCallback(async (publicToken, metadata) => {
    setLoading(true);
    setError('');

    try {
      console.log('Plaid Link Success - Starting token exchange...');
      console.log('Public token:', publicToken ? 'Received' : 'Missing');
      console.log('Metadata:', metadata);
      console.log('Selected organization:', selectedOrganization);
      
      // Check if organization is selected, try to restore from localStorage
      let currentOrg = selectedOrganization;
      if (!currentOrg || !currentOrg.id) {
        console.log('Organization lost, trying to restore from localStorage...');
        const savedOrg = localStorage.getItem('plaid-selected-org');
        if (savedOrg) {
          try {
            currentOrg = JSON.parse(savedOrg);
            setSelectedOrganization(currentOrg);
            console.log('Restored organization from localStorage:', currentOrg);
          } catch (error) {
            console.error('Error parsing saved organization:', error);
          }
        }
        
        if (!currentOrg || !currentOrg.id) {
          throw new Error('Organization selection lost. Please try again.');
        }
      }
      
      // Get donor info from token
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Authentication token lost. Please log in again.');
      }
      
      const decoded = JSON.parse(atob(token.split('.')[1]));
      const donorId = decoded.id;

      // Call your backend API to exchange public token for access token
      console.log('Exchanging public token for access token...');
      const exchangePayload = {
        public_token: publicToken,
        metadata: metadata,
        organization_id: currentOrg.id,
        donor_id: donorId
      };
      console.log('Exchange payload:', exchangePayload);

      // Try the simple API first (bypasses Prisma relation issues)
      let response = await fetch('/api/plaid/simple-exchange-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(exchangePayload)
      });

      // If simple API fails, try the original API
      if (!response.ok) {
        console.log('Simple API failed, trying original API...');
        response = await fetch('/api/plaid/exchange-token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(exchangePayload)
        });

        // If original API also fails due to network issues, try mock API
        if (!response.ok) {
          let errorData;
          try {
            errorData = await response.json();
          } catch (jsonError) {
            console.error('Failed to parse error response:', jsonError);
            errorData = { error: 'Unknown error' };
          }
          
          if (errorData.errorCode === 'NETWORK_TIMEOUT' || errorData.errorCode === 'NETWORK_ERROR') {
            console.log('Real Plaid exchange API failed due to network issues, trying mock API...');
            response = await fetch('/api/plaid/mock-exchange-token', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              },
              body: JSON.stringify(exchangePayload)
            });
          }
        }
      }

      console.log('Exchange response status:', response.status);

      if (!response.ok) {
        const errorData = await response.clone().json().catch(() => ({ error: 'Unknown error' }));
        console.error('Token exchange failed:', errorData);
        const errorMessage = `Token exchange failed: ${errorData.error || 'Unknown error'}`;
        alert(errorMessage);
        throw new Error('Failed to exchange token');
      }

      const result = await response.json();
      console.log('Token exchange successful:', result);
      
      // Show Plaid response in alert dialog
      const alertMessage = `Plaid Connection Successful!\n\n` +
        `Organization: ${selectedOrganization?.name}\n` +
        `Institution: ${result.connection?.institution_name || 'Unknown'}\n` +
        `Accounts: ${result.connection?.accounts_count || 0}\n` +
        `Status: ${result.connection?.status || 'Unknown'}\n` +
        `Connection ID: ${result.connection?.id || 'N/A'}`;
      
      alert(alertMessage);
      
      setSuccess(true);
      
      // Call success callback after a short delay
      setTimeout(() => {
        onSuccess(result);
        onClose();
      }, 2000);

    } catch (err) {
      console.error('Plaid integration error:', err);
      const errorMessage = `Plaid Connection Failed!\n\nError: ${err.message || 'Unknown error occurred'}\n\nPlease try again.`;
      alert(errorMessage);
      setError('Failed to connect bank account. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [onSuccess, onClose, selectedOrganization]);

  const onPlaidExit = useCallback((err, metadata) => {
    if (err) {
      console.error('Plaid Link Exit Error:', err);
      const exitMessage = `Plaid Connection Cancelled!\n\nReason: ${err.error_message || err.error_code || 'User cancelled'}\n\nYou can try again anytime.`;
      alert(exitMessage);
      setError('Connection was cancelled or failed. Please try again.');
    }
  }, []);

  const [linkToken, setLinkToken] = useState(null);

  const config = {
    token: linkToken,
    onSuccess: onPlaidSuccess,
    onExit: onPlaidExit,
  };

  const { open, ready } = usePlaidLink(config);

  const handleConnect = async () => {
    setLoading(true);
    setError('');

    try {
      console.log('Starting Plaid connection process...');
      console.log('Selected organization:', selectedOrganization);

      // Check if organization is selected, try to restore from localStorage
      let currentOrg = selectedOrganization;
      if (!currentOrg || !currentOrg.id) {
        console.log('Organization lost in handleConnect, trying to restore from localStorage...');
        const savedOrg = localStorage.getItem('plaid-selected-org');
        if (savedOrg) {
          try {
            currentOrg = JSON.parse(savedOrg);
            setSelectedOrganization(currentOrg);
            console.log('Restored organization from localStorage:', currentOrg);
          } catch (error) {
            console.error('Error parsing saved organization:', error);
          }
        }
        
        if (!currentOrg || !currentOrg.id) {
          throw new Error('Please select an organization first.');
        }
      }

      // Get donor info from token
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('No authentication token found. Please log in again.');
      }

      const decoded = JSON.parse(atob(token.split('.')[1]));
      const donorId = decoded.id;
      console.log('Donor ID:', donorId);

      // Get link token from backend
      console.log('Creating link token...');
      let response = await fetch('/api/plaid/create-link-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          organization_id: currentOrg.id,
          donor_id: donorId
        })
      });

      // If real API fails due to network issues, try mock API
      if (!response.ok) {
        let errorData;
        try {
          errorData = await response.clone().json();
        } catch (jsonError) {
          console.error('Failed to parse error response:', jsonError);
          errorData = { error: 'Unknown error' };
        }
        
        if (errorData.errorCode === 'NETWORK_TIMEOUT' || errorData.errorCode === 'NETWORK_ERROR') {
          console.log('Real Plaid API failed due to network issues, trying mock API...');
          response = await fetch('/api/plaid/mock-link-token', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
              organization_id: currentOrg.id,
              donor_id: donorId
            })
          });
        }
      }

      console.log('Link token response status:', response.status);

      if (!response.ok) {
        const errorData = await response.clone().json().catch(() => ({ error: 'Unknown error' }));
        console.error('Link token creation failed:', errorData);
        const errorMessage = `Failed to create link token: ${errorData.error || 'Unknown error'}`;
        alert(errorMessage);
        throw new Error(errorData.error || 'Failed to create link token');
      }

      const { link_token } = await response.json();
      console.log('Link token received:', link_token ? 'Success' : 'Failed');
      
      // Set the link token to trigger Plaid Link initialization
      setLinkToken(link_token);
      
    } catch (err) {
      console.error('Error creating link token:', err);
      const errorMessage = `Failed to initialize bank connection: ${err.message}`;
      alert(errorMessage);
      setError('Failed to initialize bank connection. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Open Plaid Link when token is ready
  useEffect(() => {
    if (linkToken && ready) {
      console.log('Opening Plaid Link with token:', linkToken.substring(0, 20) + '...');
      try {
        open();
        console.log('Plaid Link opened successfully');
      } catch (error) {
        console.error('Error opening Plaid Link:', error);
        alert(`Error opening Plaid Link: ${error.message}`);
      }
    }
  }, [linkToken, ready, open]);

  const handleNext = () => {
    if (currentStep === 1) {
      // Disclaimer step - just move to next
      setError('');
      setCurrentStep(2);
    } else if (currentStep === 2) {
      if (!selectedOrganization) {
        setError('Please select an organization');
        return;
      }
      setError('');
      setCurrentStep(3);
    }
  };

  const handleBack = () => {
    setError('');
    setCurrentStep(currentStep - 1);
  };

  const renderDisclaimerStep = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-6"
    >
      <div className="text-center">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-8 h-8 text-blue-600" />
        </div>
        <h3 className="text-xl font-semibold text-black mb-2">Important Information</h3>
        <p className="text-black">Please read the following disclaimer before proceeding</p>
      </div>

      {/* Disclaimer */}
      <div className="max-w-3xl mx-auto">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <div className="flex items-start space-x-4">
            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-sm font-bold">i</span>
            </div>
            <div className="text-sm text-blue-800 space-y-3">
              <p className="font-semibold text-lg mb-4">Disclaimer:</p>
              <p>
                To process your round-up donations securely, ChangeWorks uses Plaid to connect your bank account and Stripe to handle payment processing.
              </p>
              <p>
                Plaid is used by thousands of companies such as AMEX, Acorns, and Venmo. Stripe is used by over 300,000 companies such as Amazon, DoorDash, and Shopify.
              </p>
              <div className="bg-blue-100 border border-blue-300 rounded-lg p-4 mt-4">
                <p className="font-semibold text-blue-900 text-base">
                  Your banking information is collected only for verification and transaction purposes and is never shared with ChangeWorks or your chosen charity.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center">
        <p className="text-sm text-black">
          By clicking &quot;Next&quot;, you acknowledge that you have read and understood this disclaimer.
        </p>
      </div>
    </motion.div>
  );

  const filteredOrganizations = organizations.filter(org =>
    org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    org.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">Start Donate Change</h3>
                <p className="text-sm text-gray-600">Connect your bank account securely</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
            >
              <X size={24} />
            </button>
          </div>

          {!success ? (
            <>
              {/* Step Indicator */}
              <div className="flex items-center justify-center space-x-4 mb-6">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-all duration-200 ${
                  currentStep >= 1 
                    ? 'bg-blue-600 border-blue-600 text-white' 
                    : 'bg-gray-100 border-gray-300 text-gray-400'
                }`}>
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div className={`w-8 h-0.5 ${currentStep >= 2 ? 'bg-blue-600' : 'bg-gray-300'}`} />
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-all duration-200 ${
                  currentStep >= 2 
                    ? 'bg-blue-600 border-blue-600 text-white' 
                    : 'bg-gray-100 border-gray-300 text-gray-400'
                }`}>
                  <Building2 className="w-4 h-4" />
                </div>
                <div className={`w-8 h-0.5 ${currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-300'}`} />
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-all duration-200 ${
                  currentStep >= 3 
                    ? 'bg-blue-600 border-blue-600 text-white' 
                    : 'bg-gray-100 border-gray-300 text-gray-400'
                }`}>
                  <Target className="w-4 h-4" />
                </div>
              </div>

              {error && (
                <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}

              <AnimatePresence mode="wait">
                {currentStep === 1 && renderDisclaimerStep()}
                
                {currentStep === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="text-center">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Building2 className="w-8 h-8 text-blue-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-black mb-2">Select Organization</h4>
                      <p className="text-black text-sm">Choose which organization will receive your bank connection</p>
                    </div>

                    <div className="max-w-2xl mx-auto">
                      <div className="relative mb-4">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Search organizations..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 text-black"
                        />
                      </div>

                      <div className="max-h-64 overflow-y-auto space-y-2">
                        {loadingOrgs ? (
                          <div className="text-center py-8">
                            <Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto mb-2" />
                            <p className="text-black">Loading organizations...</p>
                          </div>
                        ) : filteredOrganizations.length > 0 ? (
                          filteredOrganizations.map((org) => (
                            <button
                              key={org.id}
                              onClick={() => {
                                console.log('Selecting organization:', org);
                                setSelectedOrganization(org);
                                // Save to localStorage and dispatch event
                                localStorage.setItem('selectedOrganization', JSON.stringify(org));
                                window.dispatchEvent(new CustomEvent('organizationChanged', { detail: org }));
                              }}
                              className={`w-full p-4 rounded-lg border-2 transition-all duration-200 text-left ${
                                selectedOrganization?.id === org.id
                                  ? 'border-blue-500 bg-blue-50'
                                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                              }`}
                            >
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                                  {org.imageUrl ? (
                                    <Image 
                                      src={buildOrgLogoUrl(org.imageUrl)} 
                                      alt={`${org.name} logo`}
                                      width={40}
                                      height={40}
                                      className="w-full h-full object-cover"
                                      onError={(e) => {
                                        e.target.style.display = 'none';
                                        e.target.nextSibling.style.display = 'flex';
                                      }}
                                    />
                                  ) : null}
                                  <div className={`w-full h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center ${org.imageUrl ? 'hidden' : 'flex'}`}>
                                    <Heart className="w-5 h-5 text-white" />
                                  </div>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h5 className="font-semibold text-black truncate">{org.name}</h5>
                                  <p className="text-sm text-black truncate">{org.email}</p>
                                </div>
                                {selectedOrganization?.id === org.id && (
                                  <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
                                )}
                              </div>
                            </button>
                          ))
                        ) : (
                          <div className="text-center py-8">
                            <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                            <p className="text-black">No organizations found</p>
                            <p className="text-sm text-black">Try adjusting your search terms</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}

                {currentStep === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="text-center">
                      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Target className="w-8 h-8 text-purple-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-black mb-2">Connect Your Bank Account</h4>
                      <p className="text-black text-sm">
                        Securely link your bank account using Plaid for {selectedOrganization?.name}
                      </p>
                      
                      {/* Selected Organization Display */}
                      {selectedOrganization && (
                        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Heart className="w-4 h-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-900">
                              Selected: {selectedOrganization.name}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-50 rounded-lg p-4">
                      <h5 className="font-semibold text-black mb-2">Selected Organization:</h5>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <Heart className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-black">{selectedOrganization?.name}</p>
                          <p className="text-sm text-black">{selectedOrganization?.email}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-center">
                      <button
                        onClick={handleBack}
                        className="flex items-center space-x-2 px-4 py-2 text-black hover:text-gray-800 transition-colors duration-200"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        <span>Change Organization</span>
                      </button>
                    </div>

                    <button
                      onClick={handleConnect}
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-purple-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                    >
                      {loading ? (
                        <div className="flex items-center justify-center space-x-2">
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>Connecting to Plaid...</span>
                        </div>
                      ) : (
                        'Connect Bank Account with Plaid'
                      )}
                    </button>

                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-black">
                        <strong>Note:</strong> This will open Plaid Link in a secure popup window to connect your bank account.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Navigation */}
              <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                <button
                  onClick={currentStep === 1 ? onClose : handleBack}
                  className="flex items-center space-x-2 px-4 py-2 text-black hover:text-gray-800 transition-colors duration-200"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{currentStep === 1 ? 'Cancel' : 'Back'}</span>
                </button>

                {(currentStep === 1 || currentStep === 2) && (
                  <button
                    onClick={handleNext}
                    disabled={currentStep === 2 && !selectedOrganization}
                    className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span>Next</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-xl font-bold text-black mb-2">Bank Account Connected!</h4>
              <p className="text-black mb-4">
                Your bank account has been successfully connected through Plaid.
              </p>
              <div className="flex items-center justify-center space-x-2 text-sm text-black">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Returning to dashboard...</span>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default PlaidIntegration;
